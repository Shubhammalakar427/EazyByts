-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2025 at 10:50 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `product`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Id` int(10) NOT NULL,
  `title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Id`, `title`) VALUES
(1, 'Web Developer'),
(2, 'Full-Stack Developer'),
(3, 'Web Designer');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(10) NOT NULL,
  `post_title` varchar(100) NOT NULL,
  `post_category` varchar(100) NOT NULL,
  `post_image` varchar(100) NOT NULL,
  `post_contant` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `post_title`, `post_category`, `post_image`, `post_contant`) VALUES
(47, 'Web Developer', '1', 'b.jpg', ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis quo quaerat ullam, excepturi optio distinctio provident nulla placeat non, impedit sed. Beatae debitis quaerat fugiat blanditiis quod iure explicabo, corrupti reprehenderit accusamus qui at officia non ea alias possimus veritatis, ipsam amet quas omnis rerum molestias placeat ut accusantium ipsum. Voluptas aperiam voluptatibus non beatae dolor placeat et omnis iure odio sit. Excepturi obcaecati sapiente adipisci ut quas quo ex aperiam nam. Porro ducimus facere labore blanditiis quasi possimus? Qui error porro exercitationem laboriosam aspernatur sunt earum mollitia suscipit enim officia? Voluptatem qui officiis saepe porro totam maiores minima fugiat illo nostrum in veniam sint, itaque sit. Deserunt voluptatibus laborum modi vitae provident quae cum? Porro commodi natus dicta illum minus debitis libero expedita ratione, quaerat, placeat, inventore odio quod repellendus eaque. '),
(48, 'Full-Stack-Developer', '2', 'b2.jpg', ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis quo quaerat ullam, excepturi optio distinctio provident nulla placeat non, impedit sed. Beatae debitis quaerat fugiat blanditiis quod iure explicabo, corrupti reprehenderit accusamus qui at officia non ea alias possimus veritatis, ipsam amet quas omnis rerum molestias placeat ut accusantium ipsum. Voluptas aperiam voluptatibus non beatae dolor placeat et omnis iure odio sit. Excepturi obcaecati sapiente adipisci ut quas quo ex aperiam nam. Porro ducimus facere labore blanditiis quasi possimus? Qui error porro exercitationem laboriosam aspernatur sunt earum mollitia suscipit enim officia? Voluptatem qui officiis saepe porro totam maiores minima fugiat illo nostrum in veniam sint, itaque sit. Deserunt voluptatibus laborum modi vitae provident quae cum? Porro commodi natus dicta illum minus debitis libero expedita ratione, quaerat, placeat, inventore odio quod repellendus eaque. '),
(49, 'Web Designer', '3', 'b3.jpg', ' Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis quo quaerat ullam, excepturi optio distinctio provident nulla placeat non, impedit sed. Beatae debitis quaerat fugiat blanditiis quod iure explicabo, corrupti reprehenderit accusamus qui at officia non ea alias possimus veritatis, ipsam amet quas omnis rerum molestias placeat ut accusantium ipsum. Voluptas aperiam voluptatibus non beatae dolor placeat et omnis iure odio sit. Excepturi obcaecati sapiente adipisci ut quas quo ex aperiam nam. Porro ducimus facere labore blanditiis quasi possimus? Qui error porro exercitationem laboriosam aspernatur sunt earum mollitia suscipit enim officia? Voluptatem qui officiis saepe porro totam maiores minima fugiat illo nostrum in veniam sint, itaque sit. Deserunt voluptatibus laborum modi vitae provident quae cum? Porro commodi natus dicta illum minus debitis libero expedita ratione, quaerat, placeat, inventore odio quod repellendus eaque. ');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `Id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`Id`, `username`, `name`, `number`, `email`) VALUES
(8, 'CMS', 'Contant Management System', '1010101010', 'cms@12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
